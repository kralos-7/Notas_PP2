namespace MiLibreria
{
    public class Calculadora
    {
        public int Sumar(int a, int b) => a + b;
        public int Restar(int a, int b) => a - b;
    }
}