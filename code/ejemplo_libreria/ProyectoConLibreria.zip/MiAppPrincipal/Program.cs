using System;
using MiLibreria;

namespace MiAppPrincipal
{
    class Programa
    {
        static void Main()
        {
            Calculadora calc = new Calculadora();
            Console.WriteLine($"5 + 3 = {calc.Sumar(5, 3)}");
            Console.WriteLine($"10 - 4 = {calc.Restar(10, 4)}");
        }
    }
}